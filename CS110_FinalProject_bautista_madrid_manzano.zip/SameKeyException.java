public class SameKeyException extends Exception{
	
}